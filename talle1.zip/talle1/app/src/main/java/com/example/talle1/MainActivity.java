package com.example.talle1;

import android.content.Intent;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    boolean checked1, checked2, checked3, confirmar = false;
    Button btn;
    RadioGroup G1, G2, G3;
    RadioButton R1, R2, R3, R4, R5, R6, R7, R8, R9;
    EditText usuario;
    TextView datos;
    String usuario1 = " ";
    int c1 = 0, c2 = 0, c3 = 0, suma = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        usuario = findViewById(R.id.usuario);
        datos = findViewById(R.id.datos);
        btn.setOnClickListener(this);

    }

    public void pregunta1(View view) {
        checked1 = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.R1:
                if (checked1) c1 = 1;
                break;
            case R.id.R2:
                if (checked1) c1 = 0;
                break;
            case R.id.R3:
                if (checked1) c1 = 0;
                break;
        }

    }

    public void pregunta2(View view) {
        checked2 = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.R4:
                if (checked2) c2 = 1;
                break;
            case R.id.R5:
                if (checked2) c2 = 0;
                break;
            case R.id.R6:
                if (checked2) c2 = 0;
                break;
        }
    }

    public void pregunta3(View view) {
        checked3 = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.R7:
                if (checked3) c3 = 1;
                break;
            case R.id.R8:
                if (checked3) c3 = 0;
                break;
            case R.id.R9:
                if (checked3) c3 = 0;
                break;
        }


    }


    public void terminar() {
        usuario1 = usuario.getText().toString().trim();
        if (usuario1.isEmpty()) {
            datos.setText("Inserte un nombre de usuario ");
        } else {
            suma = c1 + c2 + c3;
            datos.setText("Bienvenido " + usuario1 + "\n tu resutado fue: " + suma + " de 3");
        }
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("usuario", usuario1);
        outState.putInt("puntaje1", c1);
        outState.putInt("puntaje2", c2);
        outState.putInt("puntaje3", c3);
        outState.putBoolean("confirmar", confirmar);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        usuario1 = savedInstanceState.getString("usuario");
        c1 = savedInstanceState.getInt("puntaje1");
        c2 = savedInstanceState.getInt("puntaje2");
        c3 = savedInstanceState.getInt("puntaje3");
        confirmar = savedInstanceState.getBoolean("confirmar");
     if(confirmar == true){
         terminar();
     }


    }
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn:
            confirmar = true;
                terminar();
                break;
        }
    }

}
